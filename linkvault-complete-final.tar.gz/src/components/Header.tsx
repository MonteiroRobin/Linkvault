import React, { useRef } from 'react';
import { Plus, Download, Upload } from 'lucide-react';
import Image from 'next/image';
import Button from './ui/Button';

export interface HeaderProps {
  linkCount: number;
  onAddLink: () => void;
  onImport: (data: string) => void;
  onExport: () => string;
}

const Header: React.FC<HeaderProps> = ({
  linkCount,
  onAddLink,
  onImport,
  onExport,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExport = () => {
    const data = onExport();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `linkvault-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImport = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        try {
          onImport(content);
        } catch {
          alert('Erreur lors de l\'importation du fichier');
        }
      };
      reader.readAsText(file);
    }
    // Reset input value to allow importing the same file again
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <header className="bg-white shadow-sm border-b-2 border-gray-100 sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo and Title */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <Image
                src="/logo-horizontal.png"
                alt="LinkVault Logo"
                width={200}
                height={60}
                className="h-10 w-auto"
                priority
              />
            </div>
            <div className="ml-4">
              <p className="text-sm text-secondary font-sans font-normal">
                {linkCount} lien{linkCount !== 1 ? 's' : ''} sauvegardé{linkCount !== 1 ? 's' : ''}
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleImport}
              className="flex items-center space-x-2"
            >
              <Upload className="w-4 h-4" />
              <span className="hidden sm:inline">Importer</span>
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={handleExport}
              className="flex items-center space-x-2"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Exporter</span>
            </Button>

            <Button
              variant="primary"
              size="sm"
              onClick={onAddLink}
              className="flex items-center space-x-2"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Ajouter un lien</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Hidden file input for import */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".json"
        onChange={handleFileChange}
        className="hidden"
      />
    </header>
  );
};

export default Header;