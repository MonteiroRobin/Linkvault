import React from 'react';
import { ExternalLink, Edit, Trash2, Calendar, Globe } from 'lucide-react';
import { Link } from '@/lib/types';
import { formatDate, truncateText } from '@/lib/utils';
import Button from './ui/Button';
import Tag from './ui/Tag';

export interface LinkCardProps {
  link: Link;
  tags: Array<{
    id: string;
    name: string;
    color: string;
  }>;
  onEdit: (link: Link) => void;
  onDelete: (id: string) => void;
}

const LinkCard: React.FC<LinkCardProps> = ({
  link,
  tags,
  onEdit,
  onDelete,
}) => {
  const handleVisit = () => {
    window.open(link.url, '_blank', 'noopener,noreferrer');
  };

  const handleEdit = () => {
    onEdit(link);
  };

  const handleDelete = () => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer ce lien ?')) {
      onDelete(link.id);
    }
  };

  const linkTags = link.tags
    .map(tagName => tags.find(tag => tag.name === tagName))
    .filter(Boolean) as Array<{
      id: string;
      name: string;
      color: string;
    }>;

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-md transition-shadow animate-fadeIn">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2 mb-1">
            {link.favicon && (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={link.favicon}
                alt=""
                className="w-4 h-4 flex-shrink-0"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            )}
            <h3 className="text-lg font-semibold text-gray-900 truncate">
              {link.title}
            </h3>
          </div>
          
          <div className="flex items-center text-sm text-gray-500 space-x-2">
            <Globe className="w-4 h-4" />
            <span className="truncate">{link.domain || new URL(link.url).hostname}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-1 ml-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleVisit}
            className="p-2"
            title="Visiter le lien"
          >
            <ExternalLink className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleEdit}
            className="p-2"
            title="Éditer le lien"
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleDelete}
            className="p-2 text-red-600 hover:text-red-700 hover:bg-red-50"
            title="Supprimer le lien"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* URL */}
      <div className="mb-3">
        <a
          href={link.url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 hover:text-blue-800 text-sm break-all hover:underline"
        >
          {truncateText(link.url, 60)}
        </a>
      </div>

      {/* Description */}
      {link.description && (
        <div className="mb-4">
          <p className="text-gray-600 text-sm leading-relaxed">
            {link.description}
          </p>
        </div>
      )}

      {/* Tags */}
      {linkTags.length > 0 && (
        <div className="mb-4">
          <div className="flex flex-wrap gap-2">
            {linkTags.map((tag) => (
              <Tag
                key={tag.id}
                name={tag.name}
                color={tag.color}
                size="sm"
              />
            ))}
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between text-xs text-gray-400 pt-3 border-t border-gray-100">
        <div className="flex items-center space-x-1">
          <Calendar className="w-3 h-3" />
          <span>Ajouté le {formatDate(link.createdAt)}</span>
        </div>
        <div className="flex items-center space-x-4">
          {link.tags.length > 0 && (
            <span>{link.tags.length} tag{link.tags.length !== 1 ? 's' : ''}</span>
          )}
        </div>
      </div>
    </div>
  );
};

export default LinkCard;