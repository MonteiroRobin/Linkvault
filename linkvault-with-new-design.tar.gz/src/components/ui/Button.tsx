import React from 'react';
import { cn } from '@/lib/utils';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', children, ...props }, ref) => {
    return (
      <button
        className={cn(
          'inline-flex items-center justify-center rounded-lg font-medium font-sans transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed',
          {
            // Variants avec palette teal
            'bg-teal text-white hover:bg-teal/90 focus:ring-teal shadow-sm': variant === 'primary',
            'bg-teal-light text-white hover:bg-teal-light/80 focus:ring-teal-light shadow-sm': variant === 'secondary',
            'border-2 border-teal bg-transparent text-teal hover:bg-teal/5 focus:ring-teal': variant === 'outline',
            'bg-transparent text-teal hover:bg-teal/10 focus:ring-teal/20': variant === 'ghost',
            // Sizes
            'px-3 py-1.5 text-sm font-medium': size === 'sm',
            'px-4 py-2 text-base font-medium': size === 'md',
            'px-6 py-3 text-lg font-semibold': size === 'lg',
          },
          className
        )}
        ref={ref}
        {...props}
      >
        {children}
      </button>
    );
  }
);

Button.displayName = 'Button';

export default Button;