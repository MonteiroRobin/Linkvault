import React from 'react';
import { Search, ChevronUp, ChevronDown, X } from 'lucide-react';
import { SortBy, SortOrder } from '@/lib/types';
import Input from './ui/Input';
import Button from './ui/Button';
import Tag from './ui/Tag';

export interface SearchBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  sortBy: SortBy;
  sortOrder: SortOrder;
  onSortChange: (sortBy: SortBy) => void;
  onSortOrderChange: (sortOrder: SortOrder) => void;
  tags: Array<{
    id: string;
    name: string;
    color: string;
    count: number;
  }>;
  selectedTags: string[];
  onTagToggle: (tagName: string) => void;
  onClearFilters: () => void;
}

const SearchBar: React.FC<SearchBarProps> = ({
  searchQuery,
  onSearchChange,
  sortBy,
  sortOrder,
  onSortChange,
  onSortOrderChange,
  tags,
  selectedTags,
  onTagToggle,
  onClearFilters,
}) => {
  const hasActiveFilters = searchQuery.trim() !== '' || selectedTags.length > 0;

  const sortOptions = [
    { value: 'date' as SortBy, label: 'Date' },
    { value: 'title' as SortBy, label: 'Titre' },
    { value: 'url' as SortBy, label: 'URL' },
  ];

  return (
    <div className="bg-white border-b-2 border-gray-100 py-6 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Search Input */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <Input
            type="text"
            placeholder="Rechercher dans vos liens..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-10 pr-4"
          />
        </div>

        {/* Sort Controls */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-gray-700">Trier par:</span>
            <div className="flex items-center space-x-2">
              {sortOptions.map((option) => (
                <Button
                  key={option.value}
                  variant={sortBy === option.value ? 'primary' : 'ghost'}
                  size="sm"
                  onClick={() => onSortChange(option.value)}
                >
                  {option.label}
                </Button>
              ))}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onSortOrderChange(sortOrder === 'asc' ? 'desc' : 'asc')}
                className="p-2"
              >
                {sortOrder === 'asc' ? (
                  <ChevronUp className="w-4 h-4" />
                ) : (
                  <ChevronDown className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>

          {/* Clear Filters */}
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearFilters}
              className="flex items-center space-x-1 text-gray-600"
            >
              <X className="w-4 h-4" />
              <span>Effacer les filtres</span>
            </Button>
          )}
        </div>

        {/* Tags Filter */}
        {tags.length > 0 && (
          <div>
            <div className="mb-2">
              <span className="text-sm font-medium text-gray-700">
                Filtrer par tags:
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {tags.map((tag) => (
                <Tag
                  key={tag.id}
                  name={tag.name}
                  color={tag.color}
                  count={tag.count}
                  selected={selectedTags.includes(tag.name)}
                  clickable
                  onSelect={() => onTagToggle(tag.name)}
                  size="sm"
                />
              ))}
            </div>
          </div>
        )}

        {/* Active Filters Display */}
        {selectedTags.length > 0 && (
          <div>
            <div className="mb-2">
              <span className="text-sm font-medium text-gray-700">
                Tags actifs:
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {selectedTags.map((tagName) => {
                const tag = tags.find(t => t.name === tagName);
                return tag ? (
                  <Tag
                    key={tagName}
                    name={tag.name}
                    color={tag.color}
                    selected
                    removable
                    onRemove={() => onTagToggle(tagName)}
                    size="sm"
                  />
                ) : null;
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchBar;